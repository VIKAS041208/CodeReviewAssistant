import java.io.*;
import java.util.*;

public class CodeReviewAssistant {

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter path to the Java file to review:");
        String filePath = scanner.nextLine();

        File file = new File(filePath);
        if (!file.exists()) {
            System.out.println("File not found.");
            return;
        }

        List<String> comments = new ArrayList<>();
        int longMethods = 0;
        boolean hasErrors = false;

        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;
        int lineNumber = 0;
        int methodLines = 0;
        boolean insideMethod = false;

        while ((line = reader.readLine()) != null) {
            lineNumber++;

            // Rule 1: Check for missing semicolon
            if (line.trim().endsWith("}") || line.trim().endsWith("{") || line.trim().startsWith("//") || line.trim().isEmpty()) {
                // ignore
            } else if (!line.trim().endsWith(";")) {
                comments.add("Line " + lineNumber + ": Possible missing semicolon.");
                hasErrors = true;
            }

            // Rule 2: Check indentation (simple: check if it's multiple of 4)
            if (!line.trim().isEmpty()) {
                int spaces = line.indexOf(line.trim());
                if (spaces % 4 != 0) {
                    comments.add("Line " + lineNumber + ": Improper indentation.");
                    hasErrors = true;
                }
            }

            // Rule 3: Method length checker
            if (line.contains("{")) {
                insideMethod = true;
                methodLines = 1;
            } else if (insideMethod) {
                methodLines++;
                if (line.contains("}")) {
                    if (methodLines > 20) {
                        comments.add("Line " + (lineNumber - methodLines + 1) + ": Method too long (" + methodLines + " lines).");
                        hasErrors = true;
                        longMethods++;
                    }
                    insideMethod = false;
                }
            }

            // Rule 4: Variable naming convention (look for int/double/boolean etc.)
            if (line.matches(".*\\b(int|double|boolean|String)\\s+[A-Z].*;")) {
                comments.add("Line " + lineNumber + ": Variable name should follow camelCase.");
                hasErrors = true;
            }
        }

        reader.close();

        // Output comments
        System.out.println("\n===== Code Review Comments =====");
        if (comments.isEmpty()) {
            System.out.println("No issues found.");
        } else {
            for (String comment : comments) {
                System.out.println(comment);
            }
        }

        // Final verdict
        System.out.println("\n===== Verdict =====");
        if (hasErrors) {
            System.out.println("❌ Request Changes");
        } else {
            System.out.println("✅ Approve");
        }
    }
}