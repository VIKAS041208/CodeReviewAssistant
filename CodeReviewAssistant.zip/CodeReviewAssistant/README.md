# Code Review Assistant 🧠

A simple Java-based code reviewer with an HTML frontend.

## 👨‍💻 Features
- Detects issues like:
  - Missing semicolons
  - Improper naming
  - Long methods
- Verdict: ✅ Approve / ❌ Request Changes
- Interactive UI using HTML

## 📁 Files
- `CodeReviewAssistant.java` — core review logic
- `TestCode.java` — sample code with errors to test the tool
- `index.html` — user-friendly interface for testing
- `README.md` — project description and usage

## 🚀 How to Run

### Java (Backend)
1. Compile and run `CodeReviewAssistant.java` in any IDE or using terminal
2. Use `TestCode.java` as input

### HTML (Frontend Simulation)
1. Open `index.html` in your browser
2. Paste Java code into the box
3. Click “Run Code Review” to simulate results
