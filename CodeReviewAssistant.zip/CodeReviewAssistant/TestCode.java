public class TestCode {
    public static void main(String[] args){
    int Age = 25
    System.out.println("Hello");

        if (Age > 18){
        System.out.println("Adult");
        }
    }

    public static void anotherFunction() {
        int Count = 0;
        // simulate long function
        for (int i = 0; i < 30; i++) {
            Count++;
        }
    }
}